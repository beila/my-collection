browser.runtime.onMessage.addListener(async (message) => {
  if (message?.type !== "resolve-youtube-oembed") {
    throw new Error("Unsupported Neo Picker extension request.");
  }
  const source = new URL(message.url);
  const host = source.hostname.toLowerCase();
  if (
    source.protocol !== "https:"
    || !["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"].includes(
      host,
    )
  ) {
    throw new Error("Neo Picker accepts only YouTube oEmbed URLs.");
  }
  const endpoint = new URL("https://www.youtube.com/oembed");
  endpoint.searchParams.set("url", source.href);
  endpoint.searchParams.set("format", "json");
  const response = await fetch(endpoint);
  if (!response.ok) {
    throw new Error(`YouTube oEmbed returned HTTP ${response.status}.`);
  }
  return response.json();
});
