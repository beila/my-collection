(() => {
const STORAGE_KEY = "neo-picker:selection:v1";

function storedSelection() {
  try {
    const state = JSON.parse(sessionStorage.getItem(STORAGE_KEY));
    if (
      state?.sourceUrl === location.href
      && state.selected?.id
      && state.selected?.url
    ) {
      return state.selected;
    }
  } catch {
    sessionStorage.removeItem(STORAGE_KEY);
  }
  return null;
}

function clearSelection() {
  sessionStorage.removeItem(STORAGE_KEY);
}

function launchUrl(value) {
  const match = value.match(
    /^https:\/\/(?:www\.)?amazon\.(?:com|co\.uk|de|co\.jp)\/gp\/video\/detail\/([A-Z0-9]+)/i,
  );
  return match
    ? `aiv://app.primevideo.com/detail?asin=${match[1]}`
    : value;
}

const pickerOptions = {
  resolveYouTube(url) {
    return browser.runtime.sendMessage({
      type: "resolve-youtube-oembed",
      url,
    });
  },
  launchUrl,
  onSelect(selected) {
    sessionStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({sourceUrl: location.href, selected}),
    );
  },
  onClose: clearSelection,
};

if (!document.querySelector("#neo-picker-launcher")) {
  const host = document.createElement("div");
  host.id = "neo-picker-launcher";
  host.style.cssText =
    "position:fixed;right:1rem;bottom:5.5rem;z-index:2147483646";
  const shadow = host.attachShadow({mode: "open"});
  shadow.innerHTML = `
    <style>
      button{width:3.5rem;height:3.5rem;border:1px solid #edc38b;border-radius:50%;
        background:#171612;color:#edc38b;box-shadow:0 .5rem 1.5rem #0008;
        font:700 1rem/1 system-ui;cursor:pointer}
      button:focus-visible{outline:3px solid #edc38b;outline-offset:2px}
    </style>
    <button type="button" aria-label="Open Neo Picker">Neo</button>`;
  shadow.querySelector("button").addEventListener("click", () => {
    NeoPickerRuntime.open(pickerOptions);
  });
  document.documentElement.append(host);
}

function restorePicker() {
  if (document.querySelector("#neo-picker-bookmarklet")) {
    return;
  }
  const selected = storedSelection();
  if (selected) {
    NeoPickerRuntime.open({...pickerOptions, initialItem: selected});
  }
}

restorePicker();
window.addEventListener("pageshow", restorePicker);
})();
