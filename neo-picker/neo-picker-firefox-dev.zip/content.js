if (!document.querySelector("#neo-picker-launcher")) {
  const host = document.createElement("div");
  host.id = "neo-picker-launcher";
  host.style.cssText =
    "position:fixed;right:1rem;bottom:1rem;z-index:2147483646";
  const shadow = host.attachShadow({mode: "open"});
  shadow.innerHTML = `
    <style>
      button{width:3.5rem;height:3.5rem;border:1px solid #edc38b;border-radius:50%;
        background:#171612;color:#edc38b;box-shadow:0 .5rem 1.5rem #0008;
        font:700 1rem/1 system-ui;cursor:pointer}
      button:focus-visible{outline:3px solid #edc38b;outline-offset:2px}
    </style>
    <button type="button" aria-label="Open Neo Picker">Neo</button>`;
  shadow.querySelector("button").addEventListener("click", () => {
    NeoPickerRuntime.open({
      resolveYouTube(url) {
        return browser.runtime.sendMessage({
          type: "resolve-youtube-oembed",
          url,
        });
      },
    });
  });
  document.documentElement.append(host);
}
