const NeoPickerRuntime = (() => {
function openNeoPicker(options = {}) {
const existingNeoPicker = document.querySelector("#neo-picker-bookmarklet");
if (existingNeoPicker) {
  existingNeoPicker.remove();
  options.onClose?.();
  return;
}
if (!["instapaper.com", "www.instapaper.com"].includes(location.hostname)) {
  alert("Open Instapaper.");
  return;
}

const host = document.createElement("div");
host.id = "neo-picker-bookmarklet";
host.style.cssText = "position:fixed;inset:0;z-index:2147483647;";
document.documentElement.append(host);
const shadow = host.attachShadow({mode: "open"});
shadow.innerHTML = `
  <style>
    :host{all:initial;color-scheme:dark}
    *{box-sizing:border-box}
    .shell{position:fixed;inset:0;display:grid;grid-template-rows:auto minmax(0,1fr) auto;
      gap:clamp(.65rem,2vw,1.3rem);padding:clamp(.7rem,2.5vw,1.8rem);
      overflow:hidden;background:radial-gradient(circle at 85% 15%,#76411d 0,transparent 32%),
      radial-gradient(circle at 10% 90%,#263b37 0,transparent 38%),#171612;color:#f8f3e8;
      font-family:Inter,ui-sans-serif,system-ui,sans-serif}
    header{display:flex;align-items:center;justify-content:space-between;gap:.8rem}
    .brand{min-width:0}.eyebrow,.published{margin:0 0 .35rem;color:#d9b98c;font-size:.72rem;
      font-weight:700;letter-spacing:.1em;text-transform:uppercase}
    h1,h2,p{margin:0}h1{font:500 clamp(1.45rem,4vw,3rem)/.98 Georgia,serif}
    .top-actions{display:flex;gap:.5rem}
    button,a{min-height:2.7rem;border:1px solid #ffffff2b;border-radius:999px;padding:.65rem .95rem;
      background:#ffffff0d;color:inherit;font:inherit;text-align:center;text-decoration:none;cursor:pointer}
    button:disabled{cursor:wait;opacity:.55}
    button:focus-visible,a:focus-visible{border-color:#edc38b;outline:none}
    .close{width:2.7rem;padding:0;font-size:1.25rem}
    .card{display:grid;grid-template-columns:minmax(14rem,1.1fr) minmax(18rem,1fr);min-height:0;
      overflow:hidden;border:1px solid #ffffff1f;border-radius:clamp(1rem,2vw,2rem);
      background:#0d0d0be8;box-shadow:0 1.5rem 4rem #0007}
    .visual{position:relative;min-height:0;overflow:hidden;background:linear-gradient(145deg,#693d23,#1e3431)}
    .visual img{width:100%;height:100%;object-fit:cover}
    .fallback{position:absolute;right:.08em;bottom:-.22em;color:#ffffff18;
      font:400 min(44vh,40vw)/1 Georgia,serif}
    .copy{display:flex;min-height:0;flex-direction:column;justify-content:center;
      padding:clamp(1rem,4vw,3.5rem)}
    h2{display:-webkit-box;overflow:hidden;font:500 clamp(1.5rem,3.5vw,3.5rem)/1.04 Georgia,serif;
      -webkit-box-orient:vertical;-webkit-line-clamp:4}
    .description{display:-webkit-box;overflow:hidden;margin-top:clamp(.7rem,2vh,1.3rem);color:#d5d0c5;
      font-size:clamp(.88rem,1.5vw,1.1rem);line-height:1.5;-webkit-box-orient:vertical;-webkit-line-clamp:6}
    .status{min-height:1.3em;margin-top:.65rem;color:#d9b98c;font-size:.78rem}
    nav{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:.55rem}
    nav .primary{border-color:#edc38b;background:#edc38b;color:#21170f;font-weight:800}
    [hidden]{display:none!important}
    @media(max-width:760px){
      .shell{gap:.6rem;padding:.65rem}h1{font-size:clamp(1.3rem,6vw,2rem)}
      .card{grid-template-columns:1fr;grid-template-rows:minmax(7rem,42%) minmax(0,1fr)}
      .copy{padding:.9rem}h2{font-size:clamp(1.3rem,6vw,2.2rem);-webkit-line-clamp:3}
      .description{font-size:.86rem;-webkit-line-clamp:4}
      nav{grid-template-columns:repeat(2,minmax(0,1fr))}
      nav a,nav button,header button{min-height:2.45rem;padding:.5rem .65rem;font-size:.8rem}
    }
    @media(max-height:560px){
      .eyebrow,.description{display:none}.shell{padding:.5rem}
      .card{grid-template-columns:minmax(12rem,.8fr) 1fr;grid-template-rows:1fr}.copy{padding:.75rem}
    }
  </style>
  <main class="shell">
    <header>
      <div class="brand"><p class="eyebrow">Instapaper · Neo</p><h1>Pick one worth your attention.</h1></div>
      <div class="top-actions">
        <button id="choose">Choose another</button>
        <button id="close" class="close" aria-label="Close">×</button>
      </div>
    </header>
    <article class="card" aria-live="polite">
      <div class="visual">
        <img id="image" alt="" hidden>
        <div id="fallback" class="fallback" aria-hidden="true">N</div>
      </div>
      <section class="copy">
        <p id="published" class="published"></p>
        <h2 id="title">Loading Neo…</h2>
        <p id="description" class="description"></p>
        <p id="status" class="status"></p>
      </section>
    </article>
    <nav aria-label="Bookmark actions">
      <a id="original" class="primary" href="#">Open original</a>
      <a id="reader" href="#">Open in Instapaper</a>
      <button id="archive">Archive</button>
      <button id="neo" hidden>Add channel to Neo</button>
      <button id="brown" hidden>Add channel to Brown</button>
    </nav>
  </main>`;

const element = Object.fromEntries(
  [
    "choose",
    "close",
    "image",
    "fallback",
    "published",
    "title",
    "description",
    "status",
    "original",
    "reader",
    "archive",
    "neo",
    "brown",
  ].map((id) => [id, shadow.querySelector(`#${id}`)]),
);
let selected = null;
let currentUser = null;
let folders = null;
let channel = null;
let renderToken = 0;

function closePicker() {
  document.removeEventListener("keydown", onKeydown);
  host.remove();
  options.onClose?.();
}

function onKeydown(event) {
  if (event.key === "Escape") {
    closePicker();
  }
}

async function responseJson(path, options = {}) {
  const response = await fetch(NeoPickerCore.pageUrl(path, location.href), {
    cache: "no-store",
    credentials: "same-origin",
    ...options,
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(
      body.error || body.message || `Instapaper returned HTTP ${response.status}.`,
    );
  }
  return body;
}

async function responseText(path) {
  const separator = path.includes("?") ? "&" : "?";
  const response = await fetch(
    NeoPickerCore.pageUrl(`${path}${separator}_=${Date.now()}`, location.href),
    {
    cache: "no-store",
    credentials: "same-origin",
    },
  );
  if (!response.ok) {
    throw new Error(`Neo RSS returned HTTP ${response.status}.`);
  }
  return response.text();
}

function itemText(item, name) {
  const child = item.querySelector(name);
  return child ? child.textContent.trim() : "";
}

function plainText(value) {
  const documentValue = new DOMParser().parseFromString(value, "text/html");
  return documentValue.body.textContent.replace(/\s+/g, " ").trim();
}

function parseRss(value) {
  const documentValue = new DOMParser().parseFromString(value, "application/xml");
  if (documentValue.querySelector("parsererror")) {
    throw new Error("Invalid Neo RSS.");
  }
  const title = itemText(documentValue, "channel > title");
  if (title !== "Instapaper: neo") {
    throw new Error("RSS is not Neo.");
  }
  return [...documentValue.querySelectorAll("channel > item")].map((item) => ({
    url: itemText(item, "link"),
    title: itemText(item, "title"),
    description: plainText(itemText(item, "description")),
    published: itemText(item, "pubDate"),
  }));
}

async function profileBookmarks(username, folderId, rssItems) {
  const bookmarks = [];
  const remaining = new Set(
    rssItems.map((item) => NeoPickerCore.normalizedUrl(item.url)),
  );
  for (let page = 1; page <= 100; page += 1) {
    const data = await responseJson(
      `/data/profile/${encodeURIComponent(username)}?page=${page}`
      + `&folder_id=${encodeURIComponent(folderId)}&_=${Date.now()}`,
    );
    const pageBookmarks = Array.isArray(data.bookmarks) ? data.bookmarks : [];
    bookmarks.push(...pageBookmarks);
    for (const item of pageBookmarks) {
      remaining.delete(NeoPickerCore.normalizedUrl(item.url));
    }
    if (remaining.size === 0) {
      return bookmarks;
    }
    if (!data.has_next) {
      return bookmarks;
    }
  }
  throw new Error("Too many Neo pages.");
}

async function loadSession() {
  const session = await responseJson(`/data/user_session?_=${Date.now()}`);
  currentUser = session.user;
  if (!currentUser?.form_key) {
    throw new Error("Sign in to Instapaper.");
  }
  folders = Object.fromEntries(
    (currentUser.folders || []).map((folder) => [
      folder.title.toLowerCase(),
      folder,
    ]),
  );
  if (!folders.neo || !folders.brown) {
    throw new Error("Neo or Brown is missing.");
  }
}

async function liveItems() {
  await loadSession();
  const rssItems = parseRss(
    await responseText(NeoPickerCore.rssPath(currentUser, folders.neo.id)),
  );
  const profile = await profileBookmarks(
    currentUser.username,
    folders.neo.id,
    rssItems,
  );
  return NeoPickerCore.matchItems(rssItems, profile);
}

function randomValue() {
  const value = new Uint32Array(1);
  crypto.getRandomValues(value);
  return value[0] / 4294967296;
}

function setBusy(busy) {
  for (const control of [
    element.choose,
    element.archive,
    element.neo,
    element.brown,
  ]) {
    control.disabled = busy;
  }
}

function setImage(value) {
  if (value) {
    element.image.src = value;
    element.image.hidden = false;
    element.fallback.hidden = true;
  } else {
    element.image.hidden = true;
    element.image.removeAttribute("src");
    element.fallback.hidden = false;
  }
}

function showChannelActions(value) {
  channel = value;
  element.neo.hidden = !value;
  element.brown.hidden = !value;
}

async function enrichYouTube(item, token) {
  const source = NeoPickerCore.youtubeSource(item.url);
  if (!source) {
    return;
  }
  if (source === "channel") {
    showChannelActions({
      url: NeoPickerCore.canonicalChannelUrl(item.url),
      title: "",
      thumbnail: item.og_image || "",
    });
    return;
  }
  const endpoint = new URL("https://www.youtube.com/oembed");
  endpoint.searchParams.set("url", item.url);
  endpoint.searchParams.set("format", "json");
  try {
    const metadata = options.resolveYouTube
      ? await options.resolveYouTube(item.url)
      : await fetch(endpoint).then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
          }
          return response.json();
        });
    const value = NeoPickerCore.channelFromOembed(metadata);
    if (token === renderToken) {
      showChannelActions(value);
      setImage(value.thumbnail || item.og_image || "");
    }
  } catch {
    if (token === renderToken) {
      element.status.textContent = "Channel unavailable.";
    }
  }
}

function render(item) {
  selected = item;
  options.onSelect?.(item);
  renderToken += 1;
  const token = renderToken;
  showChannelActions(null);
  element.title.textContent = item.title;
  element.description.textContent =
    item.description || "No preview text is available.";
  element.published.textContent = item.published || item.site_name || "";
  element.status.textContent = "";
  element.original.href = options.launchUrl?.(item.url) || item.url;
  element.reader.href = `/read/${encodeURIComponent(item.id)}`;
  setImage(item.og_image || "");
  enrichYouTube(item, token);
}

async function choose(initial) {
  setBusy(true);
  element.status.textContent = "Refreshing…";
  try {
    const items = await liveItems();
    render(
      NeoPickerCore.selectItem(items, selected?.id, initial, randomValue()),
    );
  } catch (error) {
    element.status.textContent = error.message;
    if (!selected) {
      element.title.textContent = "Neo is unavailable.";
      element.description.textContent =
        "Sign in to Instapaper and retry.";
    }
  } finally {
    setBusy(false);
  }
}

async function mutate(path, body) {
  return responseJson(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Form-Key": currentUser.form_key,
      "X-Requested-With": "XMLHttpRequest",
    },
    body: JSON.stringify(body),
  });
}

async function archiveSelected() {
  if (!selected) {
    return;
  }
  setBusy(true);
  try {
    await mutate("/data/bookmarks/actions", {
      actions: [NeoPickerCore.bookmarkAction(selected.id, "archive")],
    });
    selected = null;
    await choose(true);
  } catch (error) {
    element.status.textContent = error.message;
  } finally {
    setBusy(false);
  }
}

async function saveChannel(folderName) {
  if (!channel || !folders?.[folderName]) {
    return;
  }
  setBusy(true);
  try {
    const created = await mutate(
      "/data/bookmarks/create",
      NeoPickerCore.createBookmarkBody(channel.url),
    );
    const bookmarkId = created.bookmark?.id || created.bookmark?.bookmark_id;
    if (!created.success || !bookmarkId) {
      throw new Error("Channel save failed.");
    }
    await mutate("/data/bookmarks/actions", {
      actions: [
        NeoPickerCore.bookmarkAction(
          bookmarkId,
          "move",
          folders[folderName].id,
        ),
      ],
    });
    const name = channel.title || "YouTube channel";
    element.status.textContent =
      `${name} was added to ${folders[folderName].title}.`;
  } catch (error) {
    element.status.textContent = error.message;
  } finally {
    setBusy(false);
  }
}

element.choose.addEventListener("click", () => choose(false));
element.close.addEventListener("click", closePicker);
element.archive.addEventListener("click", archiveSelected);
element.neo.addEventListener("click", () => saveChannel("neo"));
element.brown.addEventListener("click", () => saveChannel("brown"));
document.addEventListener("keydown", onKeydown);
if (options.initialItem) {
  render(options.initialItem);
  setBusy(true);
  loadSession()
    .catch((error) => {
      element.status.textContent = error.message;
    })
    .finally(() => setBusy(false));
} else {
  choose(true);
}
}

return {
  open: openNeoPicker,
};
})();

if (typeof module !== "undefined") {
  module.exports = NeoPickerRuntime;
}
